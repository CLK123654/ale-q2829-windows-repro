function [indices,state] = lcg_indices(state,count,upperBound)
indices = zeros(count,1);
state = uint64(state);
a = uint64(1664525);
c = uint64(1013904223);
modulus = uint64(4294967296);
for k = 1:count
    state = mod(a*state+c,modulus);
    indices(k) = floor(double(state)/double(modulus)*upperBound)+1;
end
end
