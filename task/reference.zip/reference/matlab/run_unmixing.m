function run_unmixing(inputRoot,outputRoot)
if nargin < 1, inputRoot = "../input_data"; end
if nargin < 2, outputRoot = "results.generated"; end
inputRoot = string(inputRoot); outputRoot = string(outputRoot);
contract = jsondecode(fileread(fullfile(inputRoot,"unmixing_contract.json")));
mustBeTrue(string(contract.contract_id)=="encrypted-traffic-simplex-v2","contract id mismatch");
mustBeTrue(isequal(recursive_files(inputRoot),sort(string(contract.exact_input_files(:)))),"input file boundary mismatch");
mustBeTrue(~isfolder(outputRoot) && ~isfile(outputRoot),"output path must not exist");

sig = readtable(fullfile(inputRoot,"archetype_signatures.csv"),TextType="string",VariableNamingRule="preserve");
obs = readtable(fullfile(inputRoot,"window_fingerprints.csv"),TextType="string",VariableNamingRule="preserve");
components = string(contract.component_order(:));
features = string(contract.feature_order(:));
windows = string(contract.window_order(:));
mustBeTrue(isequal(string(sig.Properties.VariableNames),["feature",components']),"signature header mismatch");
mustBeTrue(isequal(string(obs.Properties.VariableNames),["window_id",features']),"observation header mismatch");
mustBeTrue(isequal(string(sig.feature),features),"signature feature order mismatch");
mustBeTrue(isequal(string(obs.window_id),windows),"window order mismatch");

Araw = zeros(numel(features),numel(components));
for j=1:numel(components), Araw(:,j)=sig.(char(components(j))); end
Yraw = zeros(height(obs),numel(features));
for f=1:numel(features), Yraw(:,f)=obs.(char(features(f))); end
mustBeTrue(all(isfinite(Araw),'all') && all(Araw>=0,'all') && all(sum(Araw,1)>0),"invalid signature values");
mustBeTrue(all(isfinite(Yraw),'all') && all(Yraw>=0,'all') && all(sum(Yraw,2)>0),"invalid observation values");
A = Araw./sum(Araw,1);

weights=table; intervals=table; rankings=table; convergence=table;
[~,nameOrder]=sort(components); tieKey=zeros(numel(components),1); tieKey(nameOrder)=1:numel(components);
residualSums=zeros(height(obs),1);
for wi=1:height(obs)
    y=Yraw(wi,:)'/sum(Yraw(wi,:));
    [w,it,ok,obj]=fit_simplex(A,y,contract.optimizer.step_size,contract.optimizer.max_iterations,contract.optimizer.tolerance_l2);
    [~,rankOrder]=sortrows([-w,tieKey],[1 2]);
    margin=w(rankOrder(1))-w(rankOrder(2));
    weights=[weights; table(windows(wi),w(1),w(2),w(3),w(4),components(rankOrder(1)),margin,obj, ...
      'VariableNames',{'window_id','video','chat','sync','browse','dominant_component','top2_margin','objective'})]; %#ok<AGROW>
    convergence=[convergence; table(windows(wi),it,ok,obj,norm(A*w-y,2), ...
      'VariableNames',{'window_id','iterations','converged','objective','residual_l2'})]; %#ok<AGROW>
    for rank=1:numel(components)
        j=rankOrder(rank);
        rankings=[rankings; table(windows(wi),rank,components(j),w(j), ...
          'VariableNames',{'window_id','rank','component','weight'})]; %#ok<AGROW>
    end
    fitted=A*w; residual=y-fitted; residualSums(wi)=sum(residual);
    boot=zeros(contract.bootstrap.replicates_per_window,numel(components));
    state=uint64(5181+wi);
    for b=1:contract.bootstrap.replicates_per_window
        [idx,state]=lcg_indices(state,numel(features),numel(features));
        yb=max(fitted+residual(idx),0); yb=yb/sum(yb);
        [wb,~,~,~]=fit_simplex(A,yb,contract.optimizer.step_size,contract.optimizer.max_iterations,contract.optimizer.tolerance_l2);
        boot(b,:)=wb';
    end
    sortedBoot=sort(boot,1);
    for j=1:numel(components)
        intervals=[intervals; table(windows(wi),components(j),w(j),sortedBoot(5,j),sortedBoot(195,j), ...
          'VariableNames',{'window_id','component','estimate','ci_lower','ci_upper'})]; %#ok<AGROW>
    end
end

dominants=string(weights.dominant_component);
margins=containers.Map(cellstr(string(weights.window_id)),num2cell(weights.top2_margin));
mustBeTrue(all(abs(sum(weights{:,2:5},2)-1)<1e-9) && ...
    all(weights{:,2:5}>=-1e-12,'all'),"mixture weights violate simplex constraints");
mustBeTrue(all(convergence.converged) && ...
    all(convergence.iterations<=contract.optimizer.max_iterations),"one or more fits did not converge");
mustBeTrue(all(intervals.ci_lower<=intervals.ci_upper) && ...
    all(isfinite(intervals{:,3:5}),'all'),"bootstrap intervals are invalid");
mustBeTrue(all(abs(residualSums)<1e-12),"normalized residuals do not sum to zero");
summary=struct('contract_id',contract.contract_id,'windows',height(weights),'components',numel(components), ...
  'bootstrap_replicates_per_window',contract.bootstrap.replicates_per_window,'dominant_sequence',{cellstr(dominants)}, ...
  'low_margin_windows',struct('W05',margins('W05'),'W06',margins('W06')),'all_converged',all(convergence.converged));

parent=fileparts(char(outputRoot)); if isempty(parent), parent=pwd; end
stage=string(tempname(parent)); mkdir(stage); cleanup=onCleanup(@()cleanup_stage(stage)); %#ok<NASGU>
writetable(weights,fullfile(stage,"mixture_weights.csv"));
writetable(intervals,fullfile(stage,"bootstrap_intervals.csv"));
writetable(rankings,fullfile(stage,"component_rankings.csv"));
writetable(convergence,fullfile(stage,"convergence.csv"));
write_json(fullfile(stage,"unmixing_summary.json"),summary);
mustBeTrue(isequal(recursive_files(stage),sort(string(contract.exact_result_files(:)))),"result file boundary mismatch");
[ok,msg]=movefile(stage,outputRoot); mustBeTrue(ok,"atomic publish failed: "+string(msg));
end

function files=recursive_files(root)
items=dir(fullfile(root,"**","*")); items=items(~[items.isdir]); files=strings(numel(items),1);
prefix=char(root)+string(filesep);
for i=1:numel(items)
    absolute=string(fullfile(items(i).folder,items(i).name));
    files(i)=replace(extractAfter(absolute,strlength(prefix)),"\\","/");
end
files=sort(files);
end

function write_json(path,value)
fid=fopen(path,'w'); mustBeTrue(fid>=0,"cannot write "+string(path)); cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'%s\n',jsonencode(value,PrettyPrint=true));
end

function cleanup_stage(stage)
if isfolder(stage), rmdir(stage,'s'); end
end

function mustBeTrue(condition,message)
if ~condition, error('unmixing:contract','%s',message); end
end
