function w = project_simplex(v)
% Exact Euclidean projection onto w >= 0 and sum(w) = 1.
u = sort(v(:),'descend');
cssv = cumsum(u);
rho = find(u - (cssv-1)./(1:numel(u))' > 0,1,'last');
theta = (cssv(rho)-1)/rho;
w = max(v(:)-theta,0);
end
