function [w,iterations,converged,objective] = fit_simplex(A,y,stepSize,maxIterations,tolerance)
w = ones(size(A,2),1)/size(A,2);
converged = false;
for iterations = 1:maxIterations
    next = project_simplex(w-stepSize*(A'*(A*w-y)));
    if norm(next-w,2) <= tolerance
        w = next; converged = true; break;
    end
    w = next;
end
objective = 0.5*norm(A*w-y,2)^2;
end
