#边缘容量窗口形态分析材料

容量规划团队提供了六个观察窗口的八维聚合流量形态计数，以及video、chat、sync和browse四类容量原型。材料只包含形态计数，不含载荷、地址、域名、账号、设备或用户标识。

archetype_signatures.csv保存四类原型在八个特征上的签名，window_fingerprints.csv保存六个窗口的聚合计数。unmixing_contract.json规定特征与分量顺序、归一化方式、拟合方法、Bootstrap区间和输出字段。

分析结果用于容量结构评估，不用于识别具体应用、用户或通信内容。
